plugins { id("com.android.application") }

android {
    namespace = "com.motioncut.studio"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.motioncut.studio"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
