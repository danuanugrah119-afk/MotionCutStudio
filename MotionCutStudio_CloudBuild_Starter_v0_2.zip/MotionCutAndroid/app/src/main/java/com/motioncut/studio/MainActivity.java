package com.motioncut.studio;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;

public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 100;
    private static final int PICK_AUDIO = 101;
    private LinearLayout root, timelineTracks;
    private FrameLayout previewFrame;
    private ImageView imagePreview;
    private VideoView videoPreview;
    private TextView status, mediaName, playheadLabel;
    private int keyframeCount = 0;
    private int cutMarks = 0;
    private Uri selectedVideo;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,13,24));
        getWindow().setNavigationBarColor(Color.rgb(8,13,24));
        buildUi();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(13); b.setBackground(bg(Color.rgb(34,46,70), 12, Color.rgb(53,68,98)));
        b.setPadding(dp(10), dp(4), dp(10), dp(4)); b.setOnClickListener(v -> action.run()); return b;
    }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void pad(View v, int p) { v.setPadding(dp(p),dp(p),dp(p),dp(p)); }
    private void buildUi() {
        root = column(); root.setBackgroundColor(Color.rgb(8,13,24)); pad(root, 12);
        ScrollView scroller = new ScrollView(this); scroller.setFillViewport(true); scroller.addView(root);
        setContentView(scroller);

        LinearLayout header = row(); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("◢  MotionCut Studio", 20, Color.rgb(224,214,255), true); header.addView(logo, new LinearLayout.LayoutParams(0, dp(48), 1));
        header.addView(button("Project 01", () -> toast("Proyek lokal — penyimpanan proyek akan ditambahkan.")));
        root.addView(header);
        TextView sub = text("EDITOR VIDEO ANDROID · PROTOTIPE NATIVE", 10, Color.rgb(139,157,190), true); sub.setPadding(0,dp(4),0,dp(12)); root.addView(sub);

        LinearLayout imports = row();
        imports.addView(button("＋ Foto / Video", () -> pick("image/*,video/*", PICK_MEDIA)), new LinearLayout.LayoutParams(0,dp(48),1));
        View gap = new View(this); imports.addView(gap,new LinearLayout.LayoutParams(dp(8),1));
        imports.addView(button("♫ Audio", () -> pick("audio/*", PICK_AUDIO)), new LinearLayout.LayoutParams(0,dp(48),1));
        root.addView(imports);

        LinearLayout previewCard = column(); previewCard.setBackground(bg(Color.rgb(15,23,39),16,Color.rgb(37,52,78))); pad(previewCard,10);
        TextView previewTitle = text("PREVIEW", 11, Color.rgb(151,170,205), true); previewCard.addView(previewTitle);
        previewFrame = new FrameLayout(this); previewFrame.setBackground(bg(Color.rgb(3,7,15),12,0));
        LinearLayout.LayoutParams pf = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)); pf.setMargins(0,dp(8),0,dp(8)); previewCard.addView(previewFrame,pf);
        imagePreview = new ImageView(this); imagePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewFrame.addView(imagePreview,new FrameLayout.LayoutParams(-1,-1));
        videoPreview = new VideoView(this); previewFrame.addView(videoPreview,new FrameLayout.LayoutParams(-1,-1)); videoPreview.setVisibility(View.GONE);
        TextView empty = text("Pilih foto atau video dari HP lu\n\nMedia bakal muncul di sini", 14, Color.rgb(132,148,177), true); empty.setGravity(Gravity.CENTER); previewFrame.addView(empty,new FrameLayout.LayoutParams(-1,-1));
        mediaName = text("Belum ada media dipilih",12,Color.rgb(176,190,215),false); previewCard.addView(mediaName);
        root.addView(previewCard, margins(-1,-2,0,12,0,12));

        LinearLayout timeline = column(); timeline.setBackground(bg(Color.rgb(15,23,39),16,Color.rgb(37,52,78))); pad(timeline,10);
        LinearLayout timelineHead = row(); timelineHead.addView(text("TIMELINE",14,Color.WHITE,true),new LinearLayout.LayoutParams(0,dp(32),1));
        playheadLabel = text("00:00",12,Color.rgb(95,195,255),true); timelineHead.addView(playheadLabel); timeline.addView(timelineHead);
        TextView ruler = text("00:00     00:05     00:10     00:15     00:20",10,Color.rgb(132,148,177),false); ruler.setPadding(dp(4),dp(8),0,dp(8)); timeline.addView(ruler);
        timelineTracks = column(); timeline.addView(timelineTracks);
        addTrack("VIDEO 1", "+ Impor media untuk mulai", Color.rgb(37,80,139));
        addTrack("FOTO / TEKS", "Layer objek akan muncul di sini", Color.rgb(105,56,181));
        addTrack("AUDIO 1", "Pilih audio untuk menambah track", Color.rgb(15,116,112));
        root.addView(timeline,margins(-1,-2,0,0,0,12));

        LinearLayout tools = column(); tools.setBackground(bg(Color.rgb(15,23,39),16,Color.rgb(139,92,246))); pad(tools,10);
        tools.addView(text("TOOLS CEPAT",11,Color.rgb(190,168,255),true));
        LinearLayout toolrow = row();
        toolrow.addView(button("◆ Keyframe", () -> addKeyframe()), new LinearLayout.LayoutParams(0,dp(46),1));
        toolrow.addView(button("✂ Tandai potong", () -> markCut()), new LinearLayout.LayoutParams(0,dp(46),1));
        toolrow.addView(button("▶ Putar", () -> togglePlay()), new LinearLayout.LayoutParams(0,dp(46),1));
        tools.addView(toolrow,margins(-1,-2,0,8,0,0));
        tools.addView(button("Ekspor video (belum aktif)", () -> toast("Mesin render belum dipasang. Ini belum mengekspor MP4.")),margins(-1,dp(44),0,8,0,0));
        root.addView(tools);

        status = text("Siap. Impor media lokal untuk mulai.",12,Color.rgb(160,179,210),false); status.setPadding(dp(2),dp(12),dp(2),dp(6)); root.addView(status);
    }
    private LinearLayout.LayoutParams margins(int w,int h,int l,int t,int r,int b) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); p.setMargins(dp(l),dp(t),dp(r),dp(b)); return p; }
    private void addTrack(String name, String content, int color) {
        LinearLayout track = row(); track.setPadding(0,dp(5),0,dp(5));
        TextView label = text(name,10,Color.rgb(188,202,229),true); track.addView(label,new LinearLayout.LayoutParams(dp(88),dp(42)));
        TextView clip = text(content,10,Color.WHITE,false); clip.setSingleLine(true); clip.setPadding(dp(9),0,dp(8),0); clip.setBackground(bg(color,8,0));
        track.addView(clip,new LinearLayout.LayoutParams(0,dp(42),1));
        timelineTracks.addView(track);
        View line = new View(this); line.setBackgroundColor(Color.rgb(35,48,70)); timelineTracks.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
    }
    private void pick(String type, int code) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(type);
        if (type.contains(",")) i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});
        startActivityForResult(i,code);
    }
    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data); if(result!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData(); String mime=getContentResolver().getType(uri); String name=uri.getLastPathSegment();
        try { getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
        if(req==PICK_AUDIO) { mediaName.setText("Audio dipilih: "+name); status.setText("Audio lokal dipilih. Track audio penuh akan disambungkan pada tahap timeline."); toast("Audio berhasil dipilih dari penyimpanan HP."); return; }
        mediaName.setText("Media: "+name);
        if(mime!=null && mime.startsWith("video/")) {
            imagePreview.setVisibility(View.GONE); videoPreview.setVisibility(View.VISIBLE);
            for(int n=previewFrame.getChildCount()-1;n>=0;n--) { View v=previewFrame.getChildAt(n); if(v instanceof TextView) previewFrame.removeView(v); }
            videoPreview.setVideoURI(uri); videoPreview.setOnPreparedListener(mp -> { mp.setLooping(true); videoPreview.start(); }); selectedVideo=uri;
            status.setText("Video lokal dimuat ke preview. Timeline dan ekspor masih tahap pengembangan.");
        } else {
            videoPreview.stopPlayback(); videoPreview.setVisibility(View.GONE); imagePreview.setVisibility(View.VISIBLE);
            for(int n=previewFrame.getChildCount()-1;n>=0;n--) { View v=previewFrame.getChildAt(n); if(v instanceof TextView) previewFrame.removeView(v); }
            imagePreview.setImageURI(uri); status.setText("Foto lokal dimuat ke preview. Tahap berikutnya: jadikan klip timeline dengan durasi.");
        }
        toast("Media lokal berhasil dipilih.");
    }
    private void addKeyframe() { keyframeCount++; playheadLabel.setText("◆ KF "+keyframeCount); status.setText("Penanda keyframe UI ditambahkan. Interpolasi animasi belum diimplementasikan."); toast("Penanda keyframe prototipe: "+keyframeCount); }
    private void markCut() { cutMarks++; status.setText("Penanda potong #"+cutMarks+" dibuat sebagai catatan UI; belum memotong file video."); toast("Titik potong ditandai, belum memotong file."); }
    private void togglePlay() { if(videoPreview.getVisibility()==View.VISIBLE) { if(videoPreview.isPlaying()) videoPreview.pause(); else videoPreview.start(); } else toast("Impor video dulu untuk memutar preview."); }
    private void toast(String s) { android.widget.Toast.makeText(this,s,android.widget.Toast.LENGTH_SHORT).show(); }
}
