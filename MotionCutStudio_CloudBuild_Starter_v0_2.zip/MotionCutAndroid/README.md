# MotionCut Studio — Android source starter

Ini adalah source project awal Android native. **Ini belum APK jadi dan fiturnya belum lengkap.**

## Cara build lewat HP menggunakan GitHub Actions

1. Ekstrak ZIP ini di HP supaya terlihat folder `MotionCutAndroid` beserta isi di dalamnya.
2. Masuk ke GitHub lewat browser dan buat repository baru bernama `MotionCutStudio`.
3. Upload isi folder `MotionCutAndroid` ke repository (bukan upload ZIP sebagai satu file). Pastikan `app/`, `gradle.properties`, `settings.gradle.kts`, `build.gradle.kts`, dan `.github/workflows/android-apk.yml` ada di root repository.
4. Buka tab **Actions** di repository. Pilih workflow **Build MotionCut Studio APK**, lalu tekan **Run workflow**.
5. Tunggu proses selesai. Jika status hijau, buka run yang berhasil, cari **Artifacts**, lalu unduh `MotionCutStudio-debug-apk`.
6. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`. Android mungkin meminta izin untuk memasang aplikasi dari sumber tersebut.

Jika build gagal, buka run dan lihat log untuk langkah merah; pesan error itu dibutuhkan untuk memperbaiki proyek.

## Status fitur starter

- Kerangka UI editor Android dan pemilih media lokal.
- Preview media dasar.
- Timeline/keyframe masih kerangka, belum editor lengkap.
- Render/ekspor MP4 belum diimplementasikan.

## Build lokal (komputer)

Perlu JDK 17 dan Gradle 8.9. Dari folder proyek jalankan `gradle assembleDebug`.
